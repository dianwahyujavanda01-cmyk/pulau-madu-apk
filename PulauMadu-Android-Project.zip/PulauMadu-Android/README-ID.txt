PULAU MADU - PROYEK ANDROID

Isi:
- app/src/main/assets/index.html : game HTML yang sudah diarahkan ke Three.js lokal
- app/src/main/assets/three.min.js : Three.js r128 lokal
- app/src/main/java/.../MainActivity.java : pembuka game melalui Android WebView

STATUS OFFLINE:
- Tidak ada permission INTERNET di AndroidManifest.
- Three.js sudah disimpan lokal.
- Google Fonts online dilepas; game memakai font fallback lokal.
- Progress tetap memakai localStorage browser/WebView.

CARA MEMBUAT APK:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder PulauMadu-Android.
4. Tunggu Gradle Sync selesai (Android Studio mungkin perlu internet satu kali untuk mengunduh plugin/build tools).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
Ini adalah proyek sumber Android, bukan APK yang sudah dikompilasi.
Game dirancang tampil landscape dan memakai WebGL. Performa WebGL bergantung pada perangkat Android.
